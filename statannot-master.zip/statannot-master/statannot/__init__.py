__all__ = ['statannot']

from .statannot import add_stat_annotation
from .statannot import stat_test
from ._version import __version__
