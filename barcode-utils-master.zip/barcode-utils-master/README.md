# barcode-utils
A bunch of utilities to handle barcodes in sequencing data.
